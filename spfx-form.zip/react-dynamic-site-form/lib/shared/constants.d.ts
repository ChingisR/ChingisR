export declare const aliasPattern: RegExp;
//# sourceMappingURL=constants.d.ts.map