import { ServiceKey, ServiceScope } from "@microsoft/sp-core-library";
import { IGroupNameAvailability } from "../interfaces";
export interface ISharePointService {
    getValidUrl: (alias: string, managedPath: string) => Promise<string>;
    isGroupNameAvailable: (displayName: string, alias: string) => Promise<IGroupNameAvailability>;
}
export declare class SharePointService implements ISharePointService {
    static readonly serviceKey: ServiceKey<ISharePointService>;
    private _httpClient;
    private _siteUrl;
    constructor(serviceScope: ServiceScope);
    getValidUrl(alias: string, managedPath: string): Promise<string>;
    isGroupNameAvailable(displayName: string, alias: string): Promise<IGroupNameAvailability>;
}
//# sourceMappingURL=SharePointService.d.ts.map