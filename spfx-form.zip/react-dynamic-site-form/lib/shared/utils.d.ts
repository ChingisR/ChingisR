export declare function formatAlias(alias: string): string;
//# sourceMappingURL=utils.d.ts.map