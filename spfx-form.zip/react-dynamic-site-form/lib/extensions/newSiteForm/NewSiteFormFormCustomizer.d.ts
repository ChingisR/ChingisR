import { BaseFormCustomizer } from '@microsoft/sp-listview-extensibility';
/**
 * If the form customizer uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 */
export interface INewSiteFormFormCustomizerProperties {
    emailDomain?: string;
    managedPath?: string;
}
export default class NewSiteFormFormCustomizer extends BaseFormCustomizer<INewSiteFormFormCustomizerProperties> {
    onInit(): Promise<void>;
    render(): void;
    onDispose(): void;
    private _onSave;
    private _onClose;
}
//# sourceMappingURL=NewSiteFormFormCustomizer.d.ts.map