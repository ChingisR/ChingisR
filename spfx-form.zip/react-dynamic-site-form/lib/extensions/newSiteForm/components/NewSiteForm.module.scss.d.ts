declare const styles: {
    newSiteForm: string;
    fieldDescription: string;
    fieldWrapper: string;
    greenStatus: string;
    redStatus: string;
    buttonFieldContainer: string;
    buttonFieldInput: string;
    buttonFieldButton: string;
};
export default styles;
//# sourceMappingURL=NewSiteForm.module.scss.d.ts.map