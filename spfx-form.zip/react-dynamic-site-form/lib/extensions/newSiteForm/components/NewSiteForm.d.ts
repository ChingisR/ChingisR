import * as React from 'react';
import { FormDisplayMode } from '@microsoft/sp-core-library';
import { FormCustomizerContext } from '@microsoft/sp-listview-extensibility';
export interface INewSiteFormProps {
    context: FormCustomizerContext;
    displayMode: FormDisplayMode;
    emailDomain: string;
    managedPath?: string;
    onSave: () => void;
    onClose: () => void;
}
export default function NewSiteForm(props: INewSiteFormProps): React.ReactElement<INewSiteFormProps>;
//# sourceMappingURL=NewSiteForm.d.ts.map