/* tslint:disable */
require("./NewSiteForm.module.css");
const styles = {
  newSiteForm: 'newSiteForm_8777601a',
  fieldDescription: 'fieldDescription_8777601a',
  fieldWrapper: 'fieldWrapper_8777601a',
  greenStatus: 'greenStatus_8777601a',
  redStatus: 'redStatus_8777601a',
  buttonFieldContainer: 'buttonFieldContainer_8777601a',
  buttonFieldInput: 'buttonFieldInput_8777601a',
  buttonFieldButton: 'buttonFieldButton_8777601a'
};

export default styles;
/* tslint:enable */